import sys
import os
import smtplib
import re
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from PySide6.QtWidgets import QApplication, QMainWindow, QMessageBox, QFileDialog
from PySide6.QtUiTools import QUiLoader
from PySide6.QtCore import QFile

SENDER_EMAIL = "eals.tupc@gmail.com"
SENDER_PASSWORD = "buwltszgdghrexln"

EMAIL_REGEX = r"[^@]+@[^@]+\.[^@]+"

def is_valid_email(email):
    return re.match(EMAIL_REGEX, email) is not None

def send_bulk_email(sender_email, sender_password, subject, body, recipients, attachments):
    smtp_server = "smtp.gmail.com"
    smtp_port = 587

    try:
        server = smtplib.SMTP(smtp_server, smtp_port, timeout=10)
        server.starttls()
        server.login(sender_email, sender_password)

        for recipient in recipients:
            if not is_valid_email(recipient):
                return False, f"Invalid email address: {recipient}"

            # Optional personalization
            name = recipient.split('@')[0].split('.')[0].capitalize()
            personalized_body = body.replace("{{name}}", name)

            msg_root = MIMEMultipart('related')
            msg_root['From'] = sender_email
            msg_root['To'] = recipient
            msg_root['Subject'] = subject

            msg_alternative = MIMEMultipart('alternative')
            msg_root.attach(msg_alternative)

            # Blue-themed HTML layout with customizable content
            html_body = f"""
            <html>
              <body style="margin:0; padding:0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
                <div style="max-width: 600px; margin: auto; background-color: white; border: 1px solid #dcdcdc; border-radius: 8px; overflow: hidden;">
                  <div style="background-color: #005eb8; color: white; text-align: center; padding: 20px;">
                    <h1 style="margin: 0;">SMART</h1>
                    <h2 style="margin: 0;">NOTIFICATION SYSTEM</h2>
                  </div>
                  <div style="padding: 20px; color: #333;">
                    <p style="font-size: 16px;">{personalized_body}</p>
                    <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
                    <p style="font-size: 14px; color: #005eb8;"><strong>Visit Us:</strong> <a href="http://www.ealsportal.com" style="color: #005eb8;">www.ealsportal.com</a></p>
                    <p style="font-size: 14px; color: #005eb8;"><strong>Contact us:</strong> +123-456-7890</p>
                  </div>
                </div>
              </body>
            </html>
            """
            msg_alternative.attach(MIMEText(html_body, 'html'))

            for file_path in attachments:
                try:
                    with open(file_path, 'rb') as f:
                        part = MIMEBase('application', 'octet-stream')
                        part.set_payload(f.read())
                        encoders.encode_base64(part)
                        part.add_header(
                            'Content-Disposition',
                            f'attachment; filename="{os.path.basename(file_path)}"'
                        )
                        msg_root.attach(part)
                except Exception as file_error:
                    return False, f"Failed to attach file: {file_path}\n{file_error}"

            server.sendmail(sender_email, recipient, msg_root.as_string())

        server.quit()
        return True, "Emails sent successfully!"
    except smtplib.SMTPAuthenticationError:
        return False, "Authentication failed. Check your email or password."
    except Exception as e:
        return False, f"An error occurred: {e}"

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loader = QUiLoader()

        ui_path = os.path.join(os.path.dirname(__file__), "email1.ui")
        ui_file = QFile(ui_path)

        if not ui_file.exists():
            QMessageBox.critical(self, "Error", f"UI file not found at: {ui_path}")
            sys.exit(1)

        ui_file.open(QFile.ReadOnly)
        self.ui = loader.load(ui_file, self)
        ui_file.close()

        if not self.ui:
            QMessageBox.critical(self, "Error", "Failed to load the UI.")
            sys.exit(1)

        self.attachments = []

        try:
            self.ui.attach_button.clicked.connect(self.add_attachments)
            self.ui.send_button.clicked.connect(self.send_email_handler)
        except AttributeError as e:
            QMessageBox.critical(self, "Error", f"Missing UI elements.\n{e}")
            sys.exit(1)

    def add_attachments(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Attachment(s)")
        if files:
            self.attachments.extend(files)
            QMessageBox.information(self, "Attachments Added", f"{len(files)} file(s) attached.")

    def send_email_handler(self):
        try:
            to_text = self.ui.textEdit_to.toPlainText()
            subject = self.ui.textEdit_subject.toPlainText()
            body = self.ui.textEdit_body.toPlainText()
        except AttributeError:
            QMessageBox.critical(self, "UI Error", "Missing input fields in UI.")
            return

        recipients = [email.strip() for email in to_text.split(",") if email.strip()]
        if not recipients or not subject or not body:
            QMessageBox.warning(self, "Input Error", "Please fill in all fields.")
            return

        success, message = send_bulk_email(
            SENDER_EMAIL, SENDER_PASSWORD, subject, body, recipients, self.attachments
        )

        if success:
            QMessageBox.information(self, "Success", message)
            self.attachments.clear()
        else:
            QMessageBox.critical(self, "Error", message)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.ui.show()
    sys.exit(app.exec())
