# QTABLEWIDGET

from PySide6.QtWidgets import QApplication, QTableWidget

app = QApplication([])

table = QTableWidget()
table.setRowCount(5)  
table.setColumnCount(3)  



table.show()

app.exec()
