from PySide6.QtWidgets import QApplication, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget
from PySide6.QtWidgets import QHeaderView

app = QApplication([])


window = QWidget()
layout = QVBoxLayout(window)

table = QTableWidget()
table.setRowCount(4)
table.setColumnCount(2)
table.setHorizontalHeaderLabels(["Name", "Profession"])
header = table.horizontalHeader()
header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
table.resizeColumnsToContents()


korean_oppa_list_ko = [
    ("Byeon Woo Seok", "Actor"),
    ("Jongseong Park (Jay)", "Idol - ENHYPEN"),
    ("Namjoon Kim (RM)", "Idol - BTS"),
    ("Soo Hyun Kim", "Actor"),
]


for row, (name, profession) in enumerate(korean_oppa_list_ko):
    table.setItem(row, 0, QTableWidgetItem(name))  
    table.setItem(row, 1, QTableWidgetItem(profession))  

for row in range(table.rowCount()):
    for col in range(table.columnCount()):

        item = table.item(row, col)  
        if item:
            print(f"Row {row}, Col {col}: {item.text()}")  


layout.addWidget(table)
window.setLayout(layout)


window.show()
app.exec()
