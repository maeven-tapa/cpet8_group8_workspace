# QTABLEWIDGET3

from PySide6.QtWidgets import QApplication, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QPushButton
from PySide6.QtCore import Qt

app = QApplication([])

window = QWidget()
layout = QVBoxLayout(window)

table = QTableWidget()
table.setRowCount(4)
table.setColumnCount(2)
table.setHorizontalHeaderLabels(["Name", "Age"])

table.setItem(0, 0, QTableWidgetItem("Dona"))
table.setItem(0, 1, QTableWidgetItem("20"))
table.setItem(1, 0, QTableWidgetItem("Raven"))
table.setItem(1, 1, QTableWidgetItem("19"))
table.setItem(2, 0, QTableWidgetItem("Siegmond"))
table.setItem(2, 1, QTableWidgetItem("21"))
table.setItem(3, 0, QTableWidgetItem("Maeven"))
table.setItem(3, 1, QTableWidgetItem("54"))

def print_current_item():
    item = table.currentItem()
    if item:
        print(f"Currently selected item: {item.text()}")

button = QPushButton("Print Current Item")
button.clicked.connect(print_current_item)


def sort_table():
    table.sortItems(1, Qt.AscendingOrder)  


sort_button = QPushButton("Sort by Age")
sort_button.clicked.connect(sort_table)


layout.addWidget(table)
layout.addWidget(button)
layout.addWidget(sort_button)

window.setLayout(layout)
window.show()

app.exec()
