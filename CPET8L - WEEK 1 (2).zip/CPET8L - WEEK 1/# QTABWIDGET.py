# QTABWIDGET

from PySide6.QtWidgets import QApplication, QTabWidget, QWidget, QVBoxLayout, QLabel

app = QApplication([])


tab_widget = QTabWidget()


tab1 = QWidget()
tab1_layout = QVBoxLayout()
tab1_layout.addWidget(QLabel("UNO CUTIEEEEE"))
tab1.setLayout(tab1_layout)

tab2 = QWidget()
tab2_layout = QVBoxLayout()
tab2_layout.addWidget(QLabel("STILL, UNOOOO CUTIEEEE"))
tab2.setLayout(tab2_layout)




tab_widget.addTab(tab1, "Tab 1")
tab_widget.addTab(tab2, "Tab 2")






tab_widget.setCurrentIndex(1)


tab_widget.show()
app.exec()
