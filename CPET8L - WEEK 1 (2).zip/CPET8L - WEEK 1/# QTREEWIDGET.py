# QTREEWIDGET

from PySide6.QtWidgets import QApplication, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget, QPushButton

app = QApplication([])


window = QWidget()
tree = QTreeWidget()
tree.setHeaderLabels(["Movie Genres"])


genres = ["Action", "Drama", "Comedy", "Horror", "Sci-Fi"]


for genre in genres:
    tree.addTopLevelItem(QTreeWidgetItem([genre]))




clear_button = QPushButton("Clear Genres")
clear_button.clicked.connect(tree.clear)


layout = QVBoxLayout(window)
layout.addWidget(tree)
layout.addWidget(clear_button)
window.setLayout(layout)

window.show()
app.exec()

