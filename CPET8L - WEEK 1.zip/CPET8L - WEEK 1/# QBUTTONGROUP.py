# QBUTTONGROUP


from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QRadioButton, QButtonGroup, QLabel

class ButtonGroupExample(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("QButtonGroup Example")
        self.setGeometry(100, 100, 300, 200)

        # Create a vertical layout
        layout = QVBoxLayout()

        # Create label to show selected option
        self.label = QLabel("Select an option:")

        # Create a button group
        self.button_group = QButtonGroup(self)

        # Create radio buttons
        self.radio1 = QRadioButton("Option 1")
        self.radio2 = QRadioButton("Option 2")
        self.radio3 = QRadioButton("Option 3")

        # Add buttons to the group
        self.button_group.addButton(self.radio1, 1)
        self.button_group.addButton(self.radio2, 2)
        self.button_group.addButton(self.radio3, 3)

        # Connect signal when a button is clicked
        self.button_group.buttonClicked.connect(self.on_button_clicked)

        # Add widgets to layout
        layout.addWidget(self.label)
        layout.addWidget(self.radio1)
        layout.addWidget(self.radio2)
        layout.addWidget(self.radio3)

        # Set layout
        self.setLayout(layout)

    def on_button_clicked(self, button):
        selected_text = button.text()
        self.label.setText(f"Selected: {selected_text}")

# Run the application
if __name__ == "__main__":
    app = QApplication([])
    window = ButtonGroupExample()
    window.show()
    app.exec()
