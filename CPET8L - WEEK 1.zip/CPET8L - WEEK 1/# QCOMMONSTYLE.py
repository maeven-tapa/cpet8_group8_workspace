# QCOMMONSTYLE

from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QCommonStyle

class CustomStyleExample(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("QCommonStyle Example")
        self.setGeometry(100, 100, 300, 200)

        # Create a layout
        layout = QVBoxLayout()

        # Create buttons
        button1 = QPushButton("Styled Button 1")
        button2 = QPushButton("Styled Button 2")

        # Create QCommonStyle instance
        common_style = QCommonStyle()

        # Apply styles to buttons
        common_style.polish(button1)
        common_style.polish(button2)

        # Add buttons to layout
        layout.addWidget(button1)
        layout.addWidget(button2)

        # Set layout
        self.setLayout(layout)

# Run the application
if __name__ == "__main__":
    app = QApplication([])
    window = CustomStyleExample()
    window.show()
    app.exec()
