# QEXTRASELECTION

from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QPushButton
from PySide6.QtGui import QTextCharFormat, QColor

class ExtraSelectionExample(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("QTextEdit ExtraSelection Example")
        self.setGeometry(100, 100, 400, 300)

        # Create layout
        layout = QVBoxLayout()

        # Create QTextEdit widget
        self.text_edit = QTextEdit()

        # Create a button to highlight text
        highlight_button = QPushButton("Highlight Text")

        # Connect button click event to highlight function
        highlight_button.clicked.connect(self.highlight_text)

        # Add widgets to layout
        layout.addWidget(self.text_edit)
        layout.addWidget(highlight_button)

        # Set the layout for the window
        self.setLayout(layout)

    def highlight_text(self):
        # Get the text cursor from QTextEdit
        cursor = self.text_edit.textCursor()

        # Check if the cursor has selected text
        if cursor.hasSelection():
            # Define a QTextCharFormat to specify how the text will be highlighted
            extra_selection = QTextEdit.ExtraSelection()

            # Set text background color and text color
            text_format = QTextCharFormat()
            text_format.setBackground(QColor(255, 255, 0))  # Yellow background
            text_format.setForeground(QColor(0, 0, 0))  # Black text

            extra_selection.format = text_format
            extra_selection.cursor = cursor

            # Apply the extra selection to QTextEdit
            self.text_edit.setExtraSelections([extra_selection])

# Run the application
if __name__ == "__main__":
    app = QApplication([])
    window = ExtraSelectionExample()
    window.show()
    app.exec()
