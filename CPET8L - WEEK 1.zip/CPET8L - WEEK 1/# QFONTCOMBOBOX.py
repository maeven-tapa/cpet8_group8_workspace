# QFONTCOMBOBOX

from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QFontComboBox, QLabel
from PySide6.QtGui import QFont

class FontComboBoxExample(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("QFontComboBox Example")
        self.setGeometry(100, 100, 400, 300)

        # Create a layout
        layout = QVBoxLayout()

        # Create label to display the selected font
        self.label = QLabel("Select a font from the combo box below.")

        # Create QFontComboBox to display font options
        self.font_combo = QFontComboBox()

        # Connect font selection signal to a custom slot
        self.font_combo.currentFontChanged.connect(self.on_font_changed)

        # Add the label and combo box to the layout
        layout.addWidget(self.label)
        layout.addWidget(self.font_combo)

        # Set layout for the window
        self.setLayout(layout)

    def on_font_changed(self, font: QFont):
        # Change label's font when the user selects a new font
        self.label.setFont(font)
        self.label.setText(f"Font selected: {font.family()}")

# Run the application
if __name__ == "__main__":
    app = QApplication([])
    window = FontComboBoxExample()
    window.show()
    app.exec()
