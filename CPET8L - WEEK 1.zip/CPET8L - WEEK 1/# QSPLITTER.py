#  QSPLITTER

from PySide6.QtWidgets import QApplication, QWidget, QSplitter, QTextEdit, QVBoxLayout
import sys

app = QApplication(sys.argv)

# Create main window
window = QWidget()
layout = QVBoxLayout(window)

# Create a splitter
splitter = QSplitter()

# Add widgets to the splitter
text1 = QTextEdit("Left Panel")
text2 = QTextEdit("Right Panel")
splitter.addWidget(text1)
splitter.addWidget(text2)

layout.addWidget(splitter)
window.show()

sys.exit(app.exec())
